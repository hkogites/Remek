{!! file_get_contents(public_path('oldal/blog.html')) !!}


