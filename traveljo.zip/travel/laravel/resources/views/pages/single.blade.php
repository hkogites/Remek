{!! file_get_contents(public_path('oldal/single.html')) !!}


