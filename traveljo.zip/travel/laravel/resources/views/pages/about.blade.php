{!! file_get_contents(public_path('oldal/about.html')) !!}


